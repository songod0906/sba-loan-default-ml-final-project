Group 2 ML Final Project - LaTeX Source Package

Main paper source:
  paper/paper.tex

Paper bibliography/class/assets:
  paper/rho.bib
  paper/paper.bbl
  paper/rho-class/
  paper/figures/
  paper/tables/
  paper/robustness/
  paper/test_results/

Presentation source:
  presentation/presentation_v2.tex
  presentation/*.png

Compiled PDFs included at package root:
  Group 2 ML Final Project Research Paper.pdf
  Group 2 ML Final Project Presentation.pdf

Recommended paper compile command from this package:
  cd paper
  pdflatex -interaction=nonstopmode paper.tex
  biber paper
  pdflatex -interaction=nonstopmode paper.tex
  pdflatex -interaction=nonstopmode paper.tex

If biber is unavailable, paper.bbl is included so pdflatex can still render the bibliography using the saved bibliography state.
